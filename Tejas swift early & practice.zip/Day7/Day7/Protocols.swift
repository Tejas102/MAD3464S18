//
//  Protocols.swift
//  Day7
//
//  Created by Tejas Jadhav on 21/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//

import Foundation

protocol IDisplay{
    func display()
}

protocol INetPay{
    var netPay : Double? {get}
    
    init(empID: Int, empName: String, basicPay: Double, holiday: Int)
}



