//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print("Hello");

print ("Hello friends","Haalo Ishav",str,separator: "Next..")

print(1,2,3,4,5,separator : "...")

var num1 = 10
var num2 = 20
let sum = num1 + num2

print("sum of \(num1) and \(num2) is \(sum)")

print("😡😀😆","emoji","🦋 ",separator: "🇨🇦")

var x: Int
x = 10
print("values of \(x)")

var task : String?
//  print(task!)
task = "writing"

if task == nil{
    print("Yay...no task...just fun")
}
else{
    print(task!)
}

var taskList : [String]
taskList = ["singing" , "dancing" , "writing" , "eating" , "sketching"]

for activity in taskList{
    print("perform \(activity)")
}

var itr = 1
while (itr < 5) {
    print("itr : \(itr)")
    itr = itr + 1
}

itr = 10
repeat{
    print("itr : \(itr)")
    itr = itr + 10;
} while (itr <= 30 )

itr = 3

switch itr {
case 1...9:
    print("ten")
case 10:
    print("ten")
    fallthrough
case 20:
    print("twenty")
case 30,40,50:
    print("thirty or forty or fifty")
case 60...100:
    print("sixty to hundred")
default:
    print("inreachable")
}



