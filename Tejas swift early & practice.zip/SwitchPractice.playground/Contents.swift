//: Playground - noun: a place where people can play

import UIKit

var someCharacter:Character = "b"

switch someCharacter {
case "a":
    print("is an A")
case "b" , "c" :
    print("is an B or C")
default:
    print("no character")
}

