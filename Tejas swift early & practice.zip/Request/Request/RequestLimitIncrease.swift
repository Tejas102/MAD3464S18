//
//  RequestLimitIncrease.swift
//  Request
//
//  Created by Tejas Jadhav on 25/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//

import Foundation

class RequestLimitIncrease{
    var accountInfo = [
        "S1100" : AcInfo(type, "Saving" , balance : 2313.74),
        "S1200" : AcInfo(type, "Saving" , balance : 3313.94),
        "S1300" : AcInfo(type, "Chequing" , balance : 4313.54),
        "S1400" : AcInfo(type, "Saving" , balance : 5313.54)
    ]
    func processRequest(accountNo : String) throws {
        guard let accNo = accountInfo[accountNo] else{
                throw limitReachedErrors.ineligible
        }
        guard accNo.type == "Saving" else {
            throw limitReachedErrors.noSavingAc
        }
        guard accNo.balance <= 5000 else {
            throw limitReachedErrors.insufficientBalance
        }
        print("Congrats..! Your credit limit has increased.")
    }
}

struct AcInfo {
    var type : String
    var balance : Double
}
enum limitReachedErrors: Error {
    case ineligible
    case noSavingAc
    case insufficientBalance
}




