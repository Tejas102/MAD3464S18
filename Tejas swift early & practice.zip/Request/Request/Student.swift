//
//  Student.swift
//  Request
//
//  Created by Tejas Jadhav on 25/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//

import Foundation

//class Student {
//final class Student{
//private class Student{
class Student{
    var name : String?
    private static var acNo = Int?
    
    init(){
        self.name = "Unknown"
        Student.acNo = 12345
    }
    func display(){
        print("Student name : \(self.name ?? "Unknown")")
        print("Ac No : \(Student.acNo ?? 0)")
    }
    static func getAcNo() -> Int{
 //   var i = self.name
    return acNo!
    }
}
class PartTime: Student {
    var hours: Int?
    
    override init(){
        self.hours = 10
        super.init()
    }
    override func display() {
        print("Hours : \(self.hours ?? 10)")
    }
}

