//
//  main.swift
//  Request
//
//  Created by Tejas Jadhav on 25/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//

import Foundation

print("Hello, World!")

var request1 = RequestLimitIncrease()
//do{
//try request1.processRequest(accountNo: "S1100")
//} catch limitReachedErrors.ineligible{
//    print("You dont have account with our bank. Request rejected.")
//}catch limitReachedErrors.noSavingAc{
//    print("Credit Limit can only be increased if you have a Savings Account.")
//}catch limitReachedErrors.insufficientBalance{
//    print("You need minimum $5000 balance in your Savings Account to be eligible for Credit Limit increase")
//}catch{
//    print("Service disrupted...Sorry for the inconvenience.")
//}

do{
    try request1.processRequest(accountNo: "S1200")
}catch is LimitIncreaseErrors{
    print("You are not matching any of the following criteria")
    print("1. No account with bank \n2. No saving account \n3. Minimum $5000 in saving account")
}
//Static
var s1 = Student()
s1.name = "Rutvi"
Student.acNo = 987
s1.display()

var s2 = Student()
s2.name = "Jasmeet"
s2.display()












