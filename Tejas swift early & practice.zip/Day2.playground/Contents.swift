//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var coordinates = (10,0)

switch coordinates {
case (0,0):
    print("End of canvas")
case(100,100):
    print("End of canvas")
case(10,_):
    print("x axis")
case(_,20):
    print("y axis")
case(101...200, 101...200):
    print("Outside the canvas")
case(10,20):
    print("Center of canvas")
default:
    print("canvas unavailable")
}

var range = 1...100
print(range)
print(range.contains(45))
print(range.contains(453))
print("Lowerbound" , range.lowerBound)
print("upperbound" , range.upperBound)

for itr in 0..<5{
    print("itr ; , \(itr)")
}

var friends = ["simran" , "Anu" , "Aman" , "Tejas"]
var length = friends.count

for itr in 0..<length{
    print("Friends : \(friends[itr])")
}
for frnd in friends[1...]{
    print("====\(frnd)")
}

for frnd in friends[...2] {
    print("@@@\(frnd)")
}
for char in "Good😀"{
    print("character : \(char)")
}
var Tejas = """
Answer to yesterday's question
what could you have been instead of being teacher?
you know about the answer.
"""
print(Tejas)

Tejas += "I would be an Astronaut"
Tejas.append("Ohh Really !!!😀")
print(Tejas)

var day = "Saturday"
//Saturday
print("startIndex : \(day[day.startIndex])")
// print(("endIndex : \(day[day.endIndex])")

print("last character : \(day[day.index(before: day.endIndex)])")

print("second character : \(day[day.index(after: day.startIndex)])")

print("4th character : \(day[day.index(day.startIndex, offsetBy:3)])")

print("3rd from last : \(day[day.index(day.endIndex,offsetBy: 2)])")

var value = String()
value = "too much"

if value.isEmpty {
    print(value)
}


for (idx, char) in day.enumerated(){
    print("Index : " \(idx))
}

print(day.uppercased())
print(day.lowercased())

print(day.insert("!", at: day.endIndex))
print(day)

day.insert(contentsOf: " No class please", at: day.endIndex)
print(day)

day.remove(at: day.index(of: "!") ?? day.endIndex)
print(day)

idx1 = day.index(of: "N") ?? day.endIndex
var idx2 = day.index(of: "S") ?? day.endIndex
day.removeSubrange(idx1...idx2)
print(day)





