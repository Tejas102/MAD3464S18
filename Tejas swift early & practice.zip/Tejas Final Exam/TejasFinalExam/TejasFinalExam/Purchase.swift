//
//  Purchase.swift
//  TejasFinalExam
//
//  Created by Tejas Jadhav on 31/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//

import Foundation
class Purchase : Customer {
    var purchaseID : String
    var customerInfo : String
    var purchaseDate : String
    var artPurchased : String
    var amount : String
    
    override init(){
        self.purchaseID = ""
        self.customerInfo = ""
        self.purchaseDate = ""
        self.artPurchased = ""
        self.amount = ""
    }
    init(purchaseID: String, customerInfo: String, purchaseDate: String, artPurchased: String, amount: String){
        self.purchaseID = purchaseID
        self.customerInfo = customerInfo
        self.purchaseDate = purchaseDate
        self.artPurchased = artPurchased
        self.amount = amount
        
}
    var PurchaseID : Int{
        get { return self.purchaseID }
        set { self.purchaseID = newValue}
    }
    var CustomerInfo : Int{
        get { return self.customerInfo }
        set { self.customerInfo = newValue}
    }
    var PurchaseDate : Date{
        get { return self.purchaseDate }
        set{ self.purchaseDate = newValue}
    }
    var ArtPurchased : artPurchased {
        get { return self.artPurchased }
        set{ self.artPurchased = newValue}
    }
    var Amount : Int{
        get { return self.amount }
        set { self.amount = newValue}
    }
    
    func addPurchase(){
        dataHelper.displayArt()
        print("Please enter Art ID to choose any Art from the list : ")
        let selectedArtID : Int = (Int)(readLine()!)!
        
        if let selectedArt = dataHelper.searchArt(artID: selectedArtID){
            self.addPurchase() = selectedArtID()
            self.purchaseID = selectedArtID
            
            
        }else{
            print("Sorry...The product you entered is unavailable")
        }
    }
    func displayData -> String {
        var returnData = ""
        
        returnData += "\n Purchase ID : \(self.PurchaseID)"
        returnData += "\n Purchase Date : \(self.purchaseDate )"
        //        returnData += super.displayData()
        returnData += "\n Art List : "
        if !self.artPurchased.isEmpty{
            for (self, product, qty) in self.artPurchased {
                returnData += "\n \tProduct : \(Art.displayData())"
                returnData += "\n \tQuantity : \(qty)"
            }
        }else{
            returnData += "\n No art in the purchase"
        }
        returnData += "\n Purchase Amount :\(self.amount)"
        
        return returnData
    }
}
