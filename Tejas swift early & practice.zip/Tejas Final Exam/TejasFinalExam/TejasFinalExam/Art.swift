//
//  Art.swift
//  TejasFinalExam
//
//  Created by Tejas Jadhav on 31/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//

import Foundation
class Art: IDisplay {
    
     var artID: String
     var title : String
     var category : ArtCategory
     var price : Double
    
    init(){
        self.artID = ""
        self.title = ""
        self.category = ArtCategory.None
        self.price = 0.0
    }
    
    init(artID: String, title: String, category: ArtCategory, price: Double, artistID: String, name: String, country: String){
        self.artID = artID
        self.title = title
        self.category = category
        self.price = price
    }
}
