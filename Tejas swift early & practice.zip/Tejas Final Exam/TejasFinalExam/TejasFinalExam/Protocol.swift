//
//  Protocol.swift
//  TejasFinalExam
//
//  Created by Tejas Jadhav on 31/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//

import Foundation

protocol IDisplay{
    func displayData() -> String
}

public protocol CaseIterable {
    associatedtype AllCases: Collection where AllCases.Element == Self
    static var allCases: AllCases { get }
}
