//
//  Artist.swift
//  TejasFinalExam
//
//  Created by Tejas Jadhav on 31/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//

import Foundation
class Artist{
    var artistID: String
    var name : String
    var country : String
    
    init(){
        self.artistID = ""
        self.name = ""
        self.country = ""
    }
    
    init(artistID: String, name: String, country: String){
        self.artistID = artistID
        self.name = name
        self.country = country
    }
}
