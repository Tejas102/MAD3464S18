//
//  Util.swift
//  TejasFinalExam
//
//  Created by Tejas Jadhav on 31/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//

import Foundation
class Util{
    static func drawLine()
    {
        let line = String(repeating: "-", count: 100)
        print(line)
    }
}
