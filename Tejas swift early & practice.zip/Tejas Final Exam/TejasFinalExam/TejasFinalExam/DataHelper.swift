//
//  DataHelper.swift
//  TejasFinalExam
//
//  Created by Tejas Jadhav on 31/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//

import Foundation


class Datahelper {
    var ArtList = [Int : Art]()
    var CustomerList = [String : Customer]()
    
    init(){
        self.loadArtData()
        self.loadCustomerData()
    }
    func loadArtData(){
        ArtList = [:]
        
        do{
            let monalisa = try Art(artID: "A123", title: "monalisa", category: ArtCategory.Painting, price: 700, artistID: "1", name: "tejas", country: "india")
       //     ArtList[(monalisa.artID)] = monalisa
            
            let monalisa2 = try Art(artID: "A124", title: "monalisa2", category: ArtCategory.Antiques, price: 400, artistID: "2", name: "jerry", country: "canada")
         //    ArtList[(monalisa2.artID)] = monalisa2
            
            let monalisa3 = try Art(artID: "A125", title: "monalisa3", category: ArtCategory.Handcrafts, price: 600, artistID: "3", name: "tom", country: "usa")
           //  ArtList[(monalisa3.artID)] = monalisa3
            
            let monalisa4 = try Art(artID: "A126", title: "monalisa4", category: ArtCategory.Skuplture, price: 500, artistID: "4", name: "arthor", country: "antartica")
          //   ArtList[(monalisa4.artID)] = monalisa4
            
            let monalisa5 = try Art(artID: "A127", title: "monalisa5", category: ArtCategory.None, price: 200, artistID: "5", name: "lisa", country: "north pole")
      //      ArtList[(monalisa5.artID)] = monalisa5
            
            
        }catch{
            print("Error: \(error)")
        }
    }
    
    func displayArt(){
        print("Art Details")
        Util.drawLine()
        print("\t Art ID \t\t Art Name \t\t\t\t Artist \t\t Category \t\t Price")
        for (_, value) in self.ArtList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print("\t \(value.artID) ------ \(value.title) ------ \(value.category) ------ \(value.price)")
        }
        Util.drawLine()
    }

        
    
    func loadCustomerData(){
        CustomerList = [:]
        
        let eric = Customer(customerID: "C101" , name: "eric", address: "Don Mills", contactNo: "1234567", password: "eric@123")
        CustomerList[eric.customerID] = eric
        
        let eric2 = Customer(customerID: "C102", name: "eric2", address: "Shepard", contactNo: "134589", password: "eric2@123")
        CustomerList[eric2.customerID] = eric2
        
        let eric3 = Customer(customerID: "C103", name: "eric3", address: "Leslie", contactNo: "3456789", password: "eric3@123")
        CustomerList[eric3.customerID] = eric3
    }
    
    func displayCustomers(){
        for (_, _) in self.CustomerList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
       //     print(value.displayData())
        }
        Util.drawLine()
    }
    func searchArt(artID : Int) -> Art?{
        if ArtList[artID] != nil{
            return ArtList[artID]! as Art
        }
        else{
            print("Sorry..The product number you have entered is not available")
            return nil
        }
    }
        
}
