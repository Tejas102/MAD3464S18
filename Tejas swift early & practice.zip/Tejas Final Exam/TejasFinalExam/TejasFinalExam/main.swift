//
//  main.swift
//  TejasFinalExam
//
//  Created by Tejas Jadhav on 31/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//

import Foundation

var choice = 1
var dataHelper = Datahelper()
var purchase = Purchase()

while choice != 4{
    print("\n----What would you like to do today !----")
    print("\t 1 : Show Arts List ")
    print("\t 2 : Purchase Art ")
    print("\t 3 : Show Purchased Arts ")
    print("\t 4 : Exit ")
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
    case 1:
        dataHelper.displayArt()
    case 2:
        purchase.addPurchase()
    case 3:
        print(purchase.displayData())
    case 4:
        exit(0)
    default:
        print("Please enter valid menu option.")
    }
}


