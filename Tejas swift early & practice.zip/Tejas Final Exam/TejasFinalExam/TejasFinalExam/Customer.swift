//
//  Customer.swift
//  TejasFinalExam
//
//  Created by Tejas Jadhav on 31/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//

import Foundation
class Customer: IDisplay {
    var customerID: String
    var name : String
    var address : String
    var contactNo : String
    var password : String
    
    init(){
        self.customerID = ""
        self.name = ""
        self.address = ""
        self.contactNo = ""
        self.password = ""
    }
    
    init(customerID: String, name: String, address: String, contactNo: String, password: String){
        self.customerID = customerID
        self.name = name
        self.address = address
        self.contactNo = contactNo
        self.password = password
    }
}
