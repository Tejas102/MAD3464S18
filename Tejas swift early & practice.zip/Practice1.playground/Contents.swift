//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print(str)

var a = 1
var b = 2
print("a + b : " , a + b)
print("a - b : " , a - b)
print("a * b : " , a * b)
print("a / b : " , a / b)

var NumberOfApples = 20
print("NumberOfApples " , NumberOfApples)

let c = 30
print("c is " , c)

var d:Float = 1.2
print(Int(d))

var e:Double = 13.67
print(Int(round(e)))

var f:Bool = true
print(f)




