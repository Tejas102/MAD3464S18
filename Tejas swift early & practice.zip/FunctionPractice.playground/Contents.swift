//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func addTwoNumbers(using number1:Int ,and number2:Int) -> Int   {
    
    return number1 + number2
}
let sum = addTwoNumbers(using: 2, and: 3)
print(sum)



//func addTwoNo() {
//    let a = 1
//    let b = 2
//    let c = a + b
//    print(c)
//}
//
//addTwoNo()
//
//func subTwoNo() {
//    let a = 2
//    let b = 3
//    let c = a + b
//    print(c)
//}
//subTwoNo()
