//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var snackItems = [String]()
var items = ["Tornado potato" , "Shaved Ice" , "Donuts" , "Ice Cream" , "French Fries"]
var snacks : [String]
snacks = ["Tornado potato" , "Shaved Ice" , "Donuts" , "Ice Cream" , "French Fries"]

print("Snacks : \(snacks)")

for _ in snacks{
    print("Each day : \(snacks)")
}
for snack in 0..<snacks.count{
    print("New day : \(snacks[snack])")
}
for snack in snacks[2...]{
    print("New day One sided Range: \(snack)")
}
for (index , value) in snacks.enumerated()
{
    print("Index : \(index) value : \(value)")
}
var number = Array(repeating: 1, count: 5)
number[2] = 25
number[1] = 20
print("Numbers : \(number)")

var moreNumbers = Array(repeating: 0, count: 3)
moreNumbers[1] = 490
print("MoreNumbers : \(moreNumbers)")

var allNumbers = number + moreNumbers
allNumbers[5] = 120
print("All Numbers : \(allNumbers)")

var grocery = ["Pringles" , "Juice"]
grocery += ["Fruits" , "Chocolates"]
grocery.append("Tomatoes")
grocery.append("Rice")
print("Grocery : \(grocery)")

grocery[1...3] = ["Milk" , "Veggies" , "Mayo" , "Bread"]
print("Grocery : \(grocery)")

grocery.insert("Ice cream", at: 1)
grocery.remove(at: 7)
grocery.removeLast()
print("Grocery updated  : \(grocery)")

grocery.removeAll()
if grocery.isEmpty{
    print("Put everything in kitchen")
}else{
    print("go back to the market")
}

var rajnikanth = [Any]()
rajnikanth.append("Robot")
rajnikanth.append(2.0)
rajnikanth.append(1)
print("Rajnikanth : \(rajnikanth)")

// Set
var languages = Set<String>()
languages.insert("Gujrati")
languages.insert("Hindi")
languages.insert("English")
languages.insert("Telugu")
languages.insert("Punjabi")
languages.insert("Sanskrit")
print("Languages : \(languages)")

languages.remove("Sanskrit")
print("Telugu is available in class : \(languages.contains("Telugu"))")
print("Sanskrit is available in class : \(languages.contains("Sanskrit"))")

for lang in languages.sorted(){
    print("Languages : \(lang)")
}
let motherTongue : Set = ["Gujrati" , "Punjabi" , "Urdu" , "Hindi" , "Telugu" , "Marathi"]
print("MotherTongue : \(motherTongue)")
print("Union : \(languages.union(motherTongue).sorted())")
print("Intersection : \(languages.intersection(motherTongue).sorted())")
print("Symmetric difference : \(languages.symmetricDifference(motherTongue).sorted())")
print("Subtracting 1 - 2: \(languages.subtracting(motherTongue).sorted())")
print("Subtracting 2 - 1: \(languages.subtracting(motherTongue).sorted())")

var commonLangs = languages.intersection(motherTongue).sorted()
print("Common Languages : \(commonLangs)")
print(languages.isSubset(of: commonLangs))
print(languages.isSubset(of: commonLangs))
print(motherTongue.isDisjoint(with: languages))

// Dictinary
var appreciation = [String : String]()
appreciation["Day 1"] = "Potato"
appreciation["Day 3"] = "Donuts"
print("Appreciation : \(appreciation)")

print("\(appreciation.count) appreciation days")

appreciation = [:]
if appreciation.isEmpty{
    print("No appreciation 😡... just studies")
}

appreciation["Day 2"] = "Shaved Ice"
print("appreciation : \(appreciation)")

let oldItem = appreciation.updateValue("Gola", forKey: "Day 2")
print("Appreciation : \(appreciation)")
print("Old Item : \(oldItem!)")

if let day4Item = appreciation["Day 4"]{
print("Day 4 Item : \(day4Item)")
} else {
    print("Nothing for Day 4")
}
appreciation["Day 4"] = "Ice Cream"

if let removedValue = appreciation.removeValue(forKey: "Day 3")
{
    print("\(removedValue) are no longer available")
    print("appreciation : \(appreciation)")
} else {
    print("Nothing found on Day 3")
}
appreciation["Day 2"] = nil
print("appreciation : \(appreciation)")

for app in appreciation.keys{
    print("app key : \(app)")
}
for app in appreciation.values{
    print("app values : \(app)")
}
for (key, value) in appreciation{
    print("Key : \(key) value : \(value)")
}
var flight = [String : AnyObject]()
flight["number"] = "9W 234" as AnyObject
flight["Duration"] = 16 as AnyObject
flight["Cost"] = 1000.34 as AnyObject

print("Flight : \(flight)")

















