//
//  Plane.swift
//  TejasAirline
//
//  Created by Tejas Jadhav on 26/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//



import Foundation

class Plane : IDisplay{
    private var planeID : Int?
    private var planeName : String?
    private var manufecturer : String?
    private var unitPrice : Double?
    private var category : PlaneCategory?
    
    var PlaneID : Int? {
        get{ return self.planeID }
        set{ self.planeID = newValue}
    }
    var PlaneName : String? {
        get { return self.PlaneName }
        set { self.PlaneName = newValue }
    }
    var UnitPrice : Double? {
        get{ return self.unitPrice }
        set{ self.unitPrice = newValue}
    }
    var Manufecturer : String? {
        get{ return self.manufecturer}
        set{ self.manufecturer = newValue}
    }
    var Category : PlaneCategory? {
        get{ return self.category}
        set{ self.category = newValue}
    }
    
    
    //designated
    init(){
        self.planeID = 0
        self.PlaneName = ""
        self.manufecturer = ""
        self.unitPrice = 0.0
        self.category = PlaneCategory.None
    }
    
    //failable
    //throwable
    init (planeID: Int, planeName: String, manufecturer: String, unitPrice: Double, category: PlaneCategory){//} throws {
        
        //        if PlaneID == 0 {
        //            return nil
        //        }
        //
        self.planeID = planeID
        self.planeName = planeName
        self.manufecturer = manufecturer
        
        //        if unitPrice <= 0 {
        //            throw PlaneError.InvalidPlanePrice(PlaneID)
        //        }
        
        self.unitPrice = unitPrice
        self.category = category
    }
    
    //    convenience init(PlaneID: Int){
    //        self.init(PlaneID: PlaneID, PlaneName: "Unknown", manufecturer: "Unknown", unitPrice: 0.0, category: PlaneCategory.None)
    //    }
    //
    //   convenience init(PlaneName: String){
    //    self.init(PlaneID: 0, PlaneName: PlaneName, manufecturer: "Unknown", unitPrice: 0.0, category: PlaneCategory.None)
    //
    //        }
    
    func displayData() -> String{
        //        var returnData = ""
        //
        //        returnData += " Plane ID : \(self.PlaneID ?? 0)"
        //        returnData += "\n Plane Name : \(self.PlaneName ?? "")"
        //        returnData += "\n Manufecturer : \(self.manufecturer ?? "")"
        //        returnData += "\n Category : \(self.category ?? PlaneCategory.None)"
        //        returnData += "\n Unit Price : \(self.unitPrice ?? 0.0)"
        //
        //        return returnData
        
        var returnData = ""
        returnData += "\t \(self.planeID ?? 0) ------ \(self.planeName ?? "") ------ \(self.manufecturer ?? "") ------ \(self.category ?? planeCategory.None) ------ \(self.unitPrice ?? 0.0)"
        return returnData
    }
    
    func newplane(){
        print("Enter Plane ID : ")
        self.planeID = (Int)(readLine()!)
        print("Enter Plane Name : ")
        self.PlaneName = readLine()!
        print("Enter Manufecturer : ")
        self.manufecturer = readLine()!
        
        print("Please choose Plane category : ")
        for category in planeCategory.allCases{
            print("Enter \(category.rawValue) for  \(category)")
        }
        let choice = (Int)(readLine()!) ?? 5
        self.category = planeCategory(rawValue: choice)
        
        print("Enter Unit Price : ")
        self.unitPrice = (Double)(readLine()!)
    }
}
















