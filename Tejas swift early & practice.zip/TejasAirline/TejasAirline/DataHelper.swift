//
//  DataHelper.swift
//  TejasAirline
//
//  Created by Tejas Jadhav on 26/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//


import Foundation
class DataHelper{
    var PlaneList = [Int : Plane]()
    var CustomerList = [String : Customer]()
    
    init(){
        self.loadPlaneData()
        self.loadCustomersData()
    }
    
    func loadPlaneData(){
        PlaneList = [:]
        
        do{
            
            let epson = Plane(planeID: 111, planeName: "Projector", manufecturer: "Epson", unitPrice: 1000.1, category: planeCategory.Appliances)
            PlaneList[(epson.planeID!)] = epson
            
            let handcream = Plane(planeID: 111, planeName: "Handcream", manufecturer: "Glysomed", unitPrice: 12.23, category: planeCategory.Health)
            PlaneList[(handcream.PlaneID!)] = handcream
            
            let flask = Plane(planeID: 112, planeName: "Flask", manufecturer: "Contigo", unitPrice: 20, category: planeCategory.Appliances)
            PlaneList[(flask.PlaneID!)] = flask
            
            let zelda = Plane(planeID: 113, planeName: "The Legend of Zelda", manufecturer: "Nintendo", unitPrice: 27.97, category: planeCategory.Books)
            PlaneList[(zelda.PlaneID!)] = zelda
            
            let sapiens = Plane(planeID: 114, PlaneName: "Sapiens", manufecturer: "Yuval Noah Harari", unitPrice: 11.89, category: PlaneCategory.Books)
            PlaneList[(sapiens.PlaneID!)] = sapiens
            
            let socks = Plane(planeID: 115, PlaneName: "Puma Men's 6 pack Low Cut Socks", manufecturer: "Puma", unitPrice: 23.40, category: PlaneCategory.Clothing)
            PlaneList[(socks.PlaneID!)] = socks
            
            let dress = Plane(planeID: 116, PlaneName: "Women's Vintage Floral Cocktail Dress", manufecturer: "OWIN", unitPrice: 45, category: PlaneCategory.Clothing)
            PlaneList[(dress.PlaneID!)] = dress
        }
//        catch{
//            print("Error: \(error)")
//        }
    }
    
    func displayPlane(){
        print("Plane Details")
        Util.drawLine()
        print("\t ID \t\t Name \t\t\t\t Manufecturer \t\t Category \t\t Unit Price")
        for (_, value) in self.PlaneList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print("\t \(value.PlaneID!) ------ \(value.PlaneName!) ------ \(value.Manufecturer!) ------ \(value.Category!) ------ \(value.UnitPrice!)")
        }
        Util.drawLine()
    }
    
    func searchPlane(planeID : Int) -> Plane?{
        if PlaneList[planeID] != nil{
            return PlaneList[planeID]! as Plane
        }
        else{
            print("Sorry..The Plane number you have entered is not available")
            return nil
        }
    }
    
    func loadCustomersData(){
        CustomerList = [:]
        
        let Param = Customer(customerID: "C101", customerName: "Paramjeet", email: "param@mad.com", address: "114 Michigan Ave. Brampton", creditCardInfo: "4520-0100-1234-5678", shippingInfo: "Ship to lambton college between 08:00 AM to 12:00 PM")
        CustomerList[Param.CustomerID!] = Param
        
        let Santosh = Customer(customerID: "C102", customerName: "Santosh", email: "Santosh@mad.com", address: "54 Marjary Ave. DownTown. Toronto", creditCardInfo: "4520-0100-6543-8976", shippingInfo: "Deliver at Papa John's at 03PM")
        CustomerList[Santosh.CustomerID!] = Santosh
    }
    
    func displayCustomers(){
        for (_, value) in self.CustomerList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print(value.displayData())
        }
        Util.drawLine()
    }
}
