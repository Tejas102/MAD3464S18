//
//  Order.swift
//  TejasAirline
//
//  Created by Tejas Jadhav on 26/07/18.
//  Copyright © 2018 Tejas Jadhav. All rights reserved.
//


import Foundation

typealias orderItem = (planeID: Int, plane: Plane,quantity: Int)

class Order: Customer{
    private var orderID : Int
    private var orderDate : Date
    private var orderStatus : OrderStatusList?
    private var orderPlanes : [orderItem]
    private var dataHelper = DataHelper()
    
    var OrderID : Int{
        get { return self.orderID }
        set{ self.orderID = newValue}
    }
    var OrderDate : Date{
        get { return self.orderDate }
        set{ self.orderDate = newValue}
    }
    var OrderStatus : OrderStatusList?{
        get { return self.orderStatus ?? OrderStatusList.NoOrder }
        set{ self.orderStatus = newValue}
    }
    
    //computed property
    var orderAmount: Double?{
        get{
            var amount = 0.0
            if !self.orderPlanes.isEmpty{
                for (_, prod, qty) in self.orderPlanes{
                    amount += prod.UnitPrice! * (Double)(qty)
                }
            }
            return amount
        }
    }
    
    override init(){
        self.orderID = 0
        self.orderDate = DateFormatter().date(from: "")!
        self.orderStatus = OrderStatusList.NoOrder
        self.orderPlanes = []
        super.init()
    }
    
    override func displayData() -> String {
        var returnData = ""
        
        returnData += "\n Order ID : \(self.OrderID)"
        returnData += "\n Order Date : \(self.OrderDate )"
        //        returnData += super.displayData()
        returnData += "\n Planes List : "
        if !self.orderPlanes.isEmpty{
            for (_, plane, qty) in self.orderPlanes{
                returnData += "\n \tPlane : \(plane.displayData())"
                returnData += "\n \tQuantity : \(qty)"
            }
        }else{
            returnData += "\n No Planes in the order"
        }
        returnData += "\n Order Status : \(self.OrderStatus ?? OrderStatusList.NoOrder)"
        returnData += "\n Order Amount : \(self.orderAmount  ?? 0.0)"
        
        return returnData
    }
    
    func addOrder(){
        dataHelper.displayPlanes()
        print("Please enter plane ID to choose any plane from the list : ")
        let selectedPlaneID : Int = (Int)(readLine()!)!
        
        if let selectedPlane = dataHelper.searchPlane(planeID: selectedPlaneID){
            self.OrderID = selectedPlaneID
            self.OrderDate = Date()
            
            print("How many quantities do you want ? : ")
            let qty : Int = (Int)(readLine()!) ?? 1
            
            self.orderPlanes += [(planeID: selectedPlaneID, plane: selectedPlane, quantity: qty)]
            self.OrderStatus = OrderStatusList.Placed
            
        }else{
            print("Sorry...The plane you entered is unavailable")
        }
    }
    
    func cancelOrder(){
        if !orderPlanes.isEmpty {
            print("Review your order \n \(self.displayData())")
            
            print("Please enter plane ID to remove from the order : ")
            let selectedPlaneID : Int = (Int)(readLine()!)!
            var PlaneIndex = -1
            
            for (index, item) in self.orderPlanes.enumerated(){
                if (item.planeID == selectedPlaneID){
                    PlaneIndex = index
                }
            }
            
            if PlaneIndex != -1{
                self.orderPlanes.remove(at: PlaneIndex)
                print("The plane is removed from your order")
            }
        }else{
            print("You have no item in your order")
        }
    }
}
