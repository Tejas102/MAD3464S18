//: Playground - noun: a place where people can play

import UIKit

var str = "Hello Tejas"

var counter = -5

while counter > 0 {
    print(counter)
    counter -= 1
}
repeat {
print("Hello dear")
counter -= 1
} while counter > 0








//var str = "Hello, playground"
//
//var sum = 0
//
//for index in 1...5 {
//   sum += index
//
//}
//    print(sum)
