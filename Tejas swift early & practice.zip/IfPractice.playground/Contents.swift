//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

let a = 5
let b = 1
let c = 4

if a <= 4 || b<=4 && c != 4  {
    print("Branch 1")
}
else if a <= 8 && b<=8  {
    print("Branch 2")
}
else if a <= 10 && b<=10  {
    print("Branch 3")
}
else {
    print("You're an Alien")
}



