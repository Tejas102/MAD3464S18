//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

// lesson 1 variables

var a = 1
var b = 2

a = 3

var numberOfApples = 20
print("number of apples is : \(numberOfApples)")

print(a+b)
print(a-b)
print(a*b)
print(a/b)

let chp = "chapter 2 data types "
print(chp)

// lesson 2

var c:Int = 5
var d:String = "hi"
var e:Float = 1.2
var f:Double = 10.12

print(Int(c))
print(Int(e))
print(Int(round(f)))

let chp2 = "chapter 3 if statements"
print(chp2)

var g = 11
var h = 10
var i = 10

if g <= 4 && h <= 4 && i <= 4 {
    print("g is less than 4")
}
else if g <= 8 || h <= 8 || i <= 8 {
    print("g is less than 8")
}
else if g <= 10 && h <= 10 || i != 10 {
    print("g is less than equal to 10")
}
else {
    print("g is greater than 10")
}

let chp4 = "chapter 4 switch statements"
print(chp4)

var someCharacter:Character = "b"

switch someCharacter {
case "a":
    print("is an A")
case "b":
    print("is an B")
default:
    print("some fallback")
}

let chp5 = "chapter 5 loop statements"
print(chp5)

var sum = 0

for index in 1...5 {
    sum += index
}
print(sum)

let chp6 = "chapter 6 loop statements 2"
print(chp6)

var counter = 5

while counter > 0 {
    print("Hello")
    counter -= 1
}
repeat{
    print("Hello 2")
    counter -= 1
} while counter > 0

let chp7 = "chapter 7 functions"
print(chp7)

func addTwoNumbers() {
    let a = 1
    let b = 2
    let c = a + b
    print(c)
}

func subtractTwoNumbers() -> Int {
    let a = 3
    let b = 4
    let c = a - b
    return c
}
let sum2 = subtractTwoNumbers()

addTwoNumbers()
subtractTwoNumbers()

let chp8 = "chapter 8 functions 2"
print(chp8)

func twoNumbers(_ number1:Int , _ number2:Int) -> Int {

    return number1 + number2
}
let sum1 = twoNumbers(3, 4)
print(sum1 - sum2)

let chp9 = "chapter 9 classes"
print(chp9)

class BlogPost {
    var title = ""
    var body = ""
    var author = ""
    var numberOfComments = 0
    func addComment() {
        numberOfComments += 1
    }
}
let myPost = BlogPost()
myPost.author = "Tejas's Playground"
myPost.title = "The Blog"
myPost.body = "Tejas's content"
myPost.addComment()

print("blog author is : \(myPost.author)")
print("blog body is : \(myPost.body) ")
print("blog title is : \(myPost.title)")
print("Number of Comments : \(myPost.numberOfComments)")

let chp10 = "chapter 10 inheritance"
print(chp10)

class Car {
    var topspeed = 200
    func drive() {
        print("Driving at \(topspeed)")
    }
}
class FutureClass : Car {
    override func drive() {
        super.drive()
        print("Driving at \(topspeed + 50)")
    }
    func fly() {
        print("Flying")
    }
}

let myRide = Car()
myRide.topspeed
myRide.drive()

let myNewRide = FutureClass()
myNewRide.topspeed
myNewRide.drive()
myNewRide.fly()






