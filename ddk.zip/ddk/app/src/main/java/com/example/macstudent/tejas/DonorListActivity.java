package com.example.macstudent.tejas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class DonorListActivity extends AppCompatActivity implements   View.OnClickListener, AdapterView.OnItemSelectedListener  {

    TextView txtBloodGroup;
    Button btnAddDonor;


   // Spinner spnBloodGroup;
 //   Button btnAddDonor;
 //   String[] bloodgroups = {"A+" , "A-" , "B+" , "B-" , "O+" , "O-" , "AB+" , "AB-"};




    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor_list);

        btnAddDonor = findViewById(R.id.btnAddDonor);
        btnAddDonor.setOnClickListener(this);

 //       spnBloodGroup = findViewById(R.id.spnBloodGroup);
   //     ArrayAdapter bloodGroupAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,                //        bloodgroups);
      //  spnBloodGroup.setAdapter(bloodGroupAdapter);
      //  spnBloodGroup.setOnItemSelectedListener(this);



    }

    @Override
    public void onClick(View view) {

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
