package com.example.macstudent.tejas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.Calendar;

public class NewParkingActivity extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    EditText edtCarPlate;
    TextView txtAmount, txtDateTime;
    Spinner spnLot, spnSpot, spnPayment, spnCarCompany;
    Button btnAddParking;
    RadioButton rdoOne, rdoTwo, rdoThree, rdoFour;

    int parkingRate[] = {10,20,30,100};
    String[] lots = {"A" , "B" , "C" , "D" , "E"};
    String[] spot = {"1", "2", "3", "4", "5", "6"};
    String[] paymentMethods = {"Credit Card", "Debit Card", "Master Card", "American Express"};
    String[] companyNames = {"BMW", "Audi", "Jaguar", "Lexus", "Mercedes"};
    int[] logos = {R.drawable.img_bmw, R.drawable.img_audi, R.drawable.img_jaguar, R.drawable.img_lexus, R.drawable.img_mercedes};

    String selectedLot, selectedSpot, selectedPayment, selectedCompany;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_parking);

        edtCarPlate = findViewById(R.id.edtCarPlate);
        txtAmount = findViewById(R.id.txtAmount);
        txtAmount.setText("$" + parkingRate[0]);

        txtDateTime = findViewById(R.id.txtDateTime);
        txtDateTime.setText(Calendar.getInstance().getTime().toString());

        btnAddParking = findViewById(R.id.btnAddParking);
        btnAddParking.setOnClickListener(this);

        rdoOne = findViewById(R.id.rdoOne);
        rdoOne.setOnClickListener(this);

        rdoTwo = findViewById(R.id.rdoTwo);
        rdoTwo.setOnClickListener(this);

        rdoThree = findViewById(R.id.rdoThree);
        rdoThree.setOnClickListener(this);

        rdoFour = findViewById(R.id.rdoFour);
        rdoFour.setOnClickListener(this);

        spnLot = findViewById(R.id.spnLot);
        ArrayAdapter lotAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, lots);
        spnLot.setAdapter(lotAdapter);
        spnLot.setOnItemSelectedListener(this);

        spnSpot = findViewById(R.id.spnSpot);
        ArrayAdapter spotAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, spot);
        spnSpot.setAdapter(spotAdapter);
        spnSpot.setOnItemSelectedListener(this);

        spnPayment = findViewById(R.id.spnPayment);
        ArrayAdapter PaymentAdapter = new ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,paymentMethods );
        spnPayment.setAdapter(PaymentAdapter);
        spnPayment.setOnItemSelectedListener(this);

        spnCarCompany = findViewById(R.id.spnCarCompany);
        CarCompanyAdapter companyAdapter = new CarCompanyAdapter(getApplicationContext(), logos, companyNames);
        spnCarCompany.setAdapter(companyAdapter);
        spnCarCompany.setOnItemSelectedListener(this);

    }

    @Override
    public void onClick(View v)
    {
        if (v.getId() ==rdoOne.getId())
        {
            txtAmount.setText("$" + parkingRate[0]);
        }
        else if (v.getId() == rdoTwo.getId())
        {
            txtAmount.setText("$" + parkingRate[1]);
        }
        else if (v.getId() == rdoThree.getId())
        {
            txtAmount.setText("$" + parkingRate[2]);
        }
        else if (v.getId() == rdoFour.getId())
        {
            txtAmount.setText("$" + parkingRate[3]);
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
    if (adapterView.getId() == spnLot.getId())    {
        selectedLot = lots[position];
    }else if (adapterView.getId() == spnLot.getId())        {
            selectedSpot = spot[position];
        }        else if (adapterView.getId() == spnSpot.getId())        {
            selectedPayment = paymentMethods[position];
        }else if (adapterView.getId() == spnSpot.getId())    {
        selected = lots[position];
    }else if (adapterView.getId() == spnSpot.getId())
    {
        selected = lots[position];
    }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
