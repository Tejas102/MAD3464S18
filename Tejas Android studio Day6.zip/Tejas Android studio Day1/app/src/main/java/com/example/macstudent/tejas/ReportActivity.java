package com.example.macstudent.tejas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

public class ReportActivity extends AppCompatActivity {

    ListView listReport;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        listReport = findViewById(R.id.lstReport);
        listReport.setAdapter(new ReportAdapter(getApplicationContext()));

    }
}
