package com.example.macstudent.blooddonation;

public class Registration {
}
