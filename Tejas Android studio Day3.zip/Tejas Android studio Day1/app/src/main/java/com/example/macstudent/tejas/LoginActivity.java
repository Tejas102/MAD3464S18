package com.example.macstudent.tejas;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {

    Button btnLogin;
    Button btnRegister;
    EditText edtEmail;
    EditText edtPassword;

    DBHelper dbHelper;
    SQLiteDatabase ParkingDB;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        btnLogin = findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(this);

        btnRegister = findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(this);

        edtEmail = findViewById(R.id.edtEmail);
        edtPassword = findViewById(R.id.edtPassword);

        dbHelper = new DBHelper(this);

    }

    @Override
    public void onClick(View v) {

        if (v.getId() == btnLogin.getId()) {

//            String email = edtEmail.getText().toString();
  //          String password = edtPassword.getText().toString();
    //        if (email.equals("test") && password.equals("test"))

            if (verifyLogin())
            {
                Toast.makeText(this, "Login successful", Toast.LENGTH_SHORT).show();
            }else
            {
                Toast.makeText(this, "Invalid Username/Password", Toast.LENGTH_SHORT).show();
            }
        }
        else if (v.getId() == btnRegister.getId())
        {
            Toast.makeText(this, "Register clicked", Toast.LENGTH_SHORT).show();


            Intent registerIntent = new Intent(this, RegisterActivity.class);
            startActivity(registerIntent);
        }
    }
    private boolean verifyLogin()
    {
        try {
            ParkingDB = dbHelper.getReadableDatabase();
            String columns[] = {"Email" , "Password"};
            String userdata[] = {edtEmail.getText().toString() , edtPassword.getText().toString()};

            Cursor cursor = ParkingDB.query("UserInfo" , columns , "Email = ? AND Password = ?" , userdata, null, null, null);

            if (cursor != null)
            {
                if (cursor.getCount() > 0)
                {
                    return true;
                }
            }
            return false;
        }
        catch (Exception e)
        {
            Log.e("LoginActivity" , e.getMessage());
            return false;
        }
        finally {
            ParkingDB.close();
        }
    }
}