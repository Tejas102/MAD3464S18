package com.example.macstudent.tejas;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class DonorActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_donor);
    }
}
